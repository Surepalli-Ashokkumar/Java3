package com.cisco.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeployementApplicationTests {

	@Test
	void contextLoads() {
	}

}
