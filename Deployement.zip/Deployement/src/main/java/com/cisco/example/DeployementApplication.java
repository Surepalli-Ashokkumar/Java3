package com.cisco.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeployementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeployementApplication.class, args);
	}

}
