package com.simplilearn.demo.SpringSetupDemo;

public class Hello {
	
	public void helloWorld() {
		System.out.println("Welcome from Hello Class");
	}

}
