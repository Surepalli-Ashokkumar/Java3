Collect, search and visualise log data with ELK (Elasticsearch 8.3.3, Logstash 8.3.3, Kibana 8.3.3).
